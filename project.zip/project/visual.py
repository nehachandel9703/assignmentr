import matplotlib.pyplot as plt

def plot_pie_chart(data):
    park_counts = {}
    for row in data:
        park = row['Branch']
        park_counts[park] = park_counts.get(park, 0) + 1
    labels = park_counts.keys()
    sizes = park_counts.values()
    plt.pie(sizes, labels=labels, autopct='%1.1f%%')
    plt.title('Number of Reviews per Park')
    plt.show()

def plot_bar_chart_avg_scores(data):
    park_scores = {}
    park_counts = {}
    for row in data:
        park = row['Branch']
        rating = float(row['Rating'])
        park_scores[park] = park_scores.get(park, 0) + rating
        park_counts[park] = park_counts.get(park, 0) + 1
    avg_scores = {park: park_scores[park] / park_counts[park] for park in park_scores}
    plt.bar(avg_scores.keys(), avg_scores.values())
    plt.title('Average Scores per Park')
    plt.xlabel('Park')
    plt.ylabel('Average Rating')
    plt.show()

def plot_top_locations(data, park):
    location_ratings = {}
    location_counts = {}
    for row in data:
        if row['Branch'] == park:
            location = row['Reviewer_Location']
            rating = float(row['Rating'])
            location_ratings[location] = location_ratings.get(location, 0) + rating
            location_counts[location] = location_counts.get(location, 0) + 1
    avg_ratings = {location: location_ratings[location] / location_counts[location] for location in location_ratings}
    sorted_avg_ratings = dict(sorted(avg_ratings.items(), key=lambda item: item[1], reverse=True)[:10])
    plt.bar(sorted_avg_ratings.keys(), sorted_avg_ratings.values())
    plt.title(f'Top 10 Locations by Rating for {park}')
    plt.xlabel('Location')
    plt.ylabel('Average Rating')
    plt.xticks(rotation=90)
    plt.show()

def plot_monthly_avg_ratings(avg_monthly_ratings, park):
    months = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']
    avg_ratings = [avg_monthly_ratings.get(month, 0) for month in months]
    plt.bar(months, avg_ratings)
    plt.title(f'Average Monthly Ratings for {park}')
    plt.xlabel('Month')
    plt.ylabel('Average Rating')
    plt.xticks(months, ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
    plt.show()
