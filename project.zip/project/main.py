from tui import display_menu, display_submenu_a, display_submenu_b, display_submenu_c
from process import read_data, get_reviews_for_park, count_reviews_by_location, get_average_rating_by_year, get_monthly_average_ratings, get_average_score_by_location
from visual import plot_pie_chart, plot_bar_chart_avg_scores, plot_top_locations, plot_monthly_avg_ratings
from aggregator import ParkDataAggregator
from exporter import TXTExporter, CSVExporter, JSONExporter

def main():
    data = read_data(file_path='data/disneyland_reviews.csv')
    if data:
        print(f"Dataset loaded successfully with {len(data)} rows.")
    else:
        print("Failed to load dataset.")
        return

    aggregator = ParkDataAggregator(data)
    aggregated_data = aggregator.aggregated_data

    while True:
        choice = display_menu()
        if choice == 'A':
            print("You have choosen option A - View Data")
            while True:
                sub_choice = display_submenu_a()
                if sub_choice == '1':
                    park = input("Enter the name of the park: ")
                    reviews = get_reviews_for_park(data, park)
                    print(f"Reviews for {park}:")
                    for review in reviews:
                        print(review)
                elif sub_choice == '2':
                    park = input("Enter the name of the park: ")
                    location = input("Enter the reviewer's location: ")
                    count = count_reviews_by_location(data, park, location)
                    print(f"Number of reviews for {park} from {location}: {count}")
                elif sub_choice == '3':
                    park = input("Enter the name of the park: ")
                    year = input("Enter the year: ")
                    avg_rating = get_average_rating_by_year(data, park, year)
                    print(f"Average rating for {park} in {year}: {avg_rating}")
                elif sub_choice == '4':
                    avg_location_ratings = get_average_score_by_location(data)
                    for park, locations in avg_location_ratings.items():
                        print(f"Average ratings for {park} by location:")
                        for location, avg_rating in locations.items():
                            print(f"{location}: {avg_rating:.2f}")
                elif sub_choice == '0':
                    break
                else:
                    print("Invalid choice. Please try again.")
        elif choice == 'B':
            print("You have choosen option B - Visualise Data")
            while True:
                sub_choice = display_submenu_b()
                if sub_choice == '1':
                    plot_pie_chart(data)
                elif sub_choice == '2':
                    plot_bar_chart_avg_scores(data)
                elif sub_choice == '3':
                    park = input("Enter the name of the park: ")
                    plot_top_locations(data, park)
                elif sub_choice == '4':
                    park = input("Enter the name of the park: ")
                    avg_monthly_ratings = get_monthly_average_ratings(data, park)
                    plot_monthly_avg_ratings(avg_monthly_ratings, park)
                elif sub_choice == '0':
                    break
                else:
                    print("Invalid choice. Please try again.")
        elif choice == 'C':
            print("You have choosen option C - Export Data")
            while True:
                sub_choice = display_submenu_c()
                if sub_choice == '1':
                    exporter = TXTExporter(aggregated_data)
                elif sub_choice == '2':
                    exporter = CSVExporter(aggregated_data)
                elif sub_choice == '3':
                    exporter = JSONExporter(aggregated_data)
                elif sub_choice == '0':
                    break
                else:
                    print("Invalid choice. Please try again.")
                    continue
                
                file_path = input("Enter the file path for export if you want to export in same folder just write filename with extension. i.e to save in txt write filename.txt: ")
                exporter.export(file_path)
                print(f"Data exported successfully to {file_path}")
        elif choice == 'X':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
