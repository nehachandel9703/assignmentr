# aggregator.py
import csv
import json

class ParkDataAggregator:
    def __init__(self, data):
        self.data = data
        self.aggregated_data = self.aggregate_data()

    def aggregate_data(self):
        park_info = {}
        for row in self.data:
            park = row['Branch']
            rating = float(row['Rating'])
            location = row['Reviewer_Location']
            is_positive = rating >= 3

            if park not in park_info:
                park_info[park] = {
                    'num_reviews': 0,
                    'num_positive_reviews': 0,
                    'total_rating': 0,
                    'countries': set(),
                }
            park_info[park]['num_reviews'] += 1
            if is_positive:
                park_info[park]['num_positive_reviews'] += 1
            park_info[park]['total_rating'] += rating
            park_info[park]['countries'].add(location)
        
        for park in park_info:
            park_info[park]['avg_rating'] = (
                park_info[park]['total_rating'] / park_info[park]['num_reviews']
            )
            park_info[park]['num_countries'] = len(park_info[park]['countries'])
            del park_info[park]['total_rating']
            del park_info[park]['countries']

        return park_info