def display_menu():
    print("---------------------------")
    print("Disneyland Reviews Analyser")
    print("---------------------------")
    print("Please enter the letter which corresponds with your desired menu choice")
    print("    [A] View data")
    print("    [B] Visualise data")
    print("    [C] Export data")
    print("    [X] Exit")
    return input("Enter your choice: ").upper()

def display_submenu_a():
    print("View Data Menu")
    print("1. View all reviews for a park")
    print("2. Count reviews by location")
    print("3. Average rating by year")
    print("4. Average score per park by reviewer location")
    print("0. Back to main menu")
    return input("Enter your choice: ")

def display_submenu_b():
    print("Visualise Data Menu")
    print("1. Pie chart of reviews by park")
    print("2. Bar chart of average scores by park")
    print("3. Top 10 locations by rating for a park")
    print("4. Monthly ratings for a park")
    print("0. Back to main menu")
    return input("Enter your choice: ")

def display_submenu_c():
    print("Export Data Menu")
    print("1. Export as TXT")
    print("2. Export as CSV")
    print("3. Export as JSON")
    print("0. Back to main menu")
    return input("Enter your choice: ")