import csv

def read_data(file_path='data/disneyland_reviews.csv'):
    try:
        with open(file_path, mode='r') as file:
            csv_reader = csv.DictReader(file)
            data = [row for row in csv_reader]
        return data
    except Exception as e:
        # Suppress error output
        return None

def get_reviews_for_park(data, park):
    return [row for row in data if row['Branch'] == park]

def count_reviews_by_location(data, park, location):
    return sum(1 for row in data if row['Branch'] == park and row['Reviewer_Location'] == location)

def get_average_rating_by_year(data, park, year):
    ratings = [float(row['Rating']) for row in data if row['Branch'] == park and row['Year_Month'].startswith(year)]
    return sum(ratings) / len(ratings) if ratings else 0

def get_monthly_average_ratings(data, park):
    monthly_ratings = {f'{i:02d}': [] for i in range(1, 13)}
    for row in data:
        if row['Branch'] == park:
            year_month = row['Year_Month']
            if '-' in year_month:
                try:
                    year, month = year_month.split('-')
                    month = f'{int(month):02d}'  # Ensure month is zero-padded
                    rating = float(row['Rating'])
                    monthly_ratings[month].append(rating)
                except ValueError:
                    continue  # Ignore rows with parsing errors
                except KeyError:
                    continue  # Ignore rows with missing keys
                except Exception:
                    continue  # Catch any other unexpected errors
    avg_monthly_ratings = {month: sum(ratings) / len(ratings) if ratings else 0 for month, ratings in monthly_ratings.items()}
    return avg_monthly_ratings

def get_average_score_by_location(data):
    location_ratings = {}
    for row in data:
        park = row['Branch']
        location = row['Reviewer_Location']
        rating = float(row['Rating'])
        if park not in location_ratings:
            location_ratings[park] = {}
        if location not in location_ratings[park]:
            location_ratings[park][location] = []
        location_ratings[park][location].append(rating)

    avg_location_ratings = {}
    for park, locations in location_ratings.items():
        avg_location_ratings[park] = {location: sum(ratings) / len(ratings) for location, ratings in locations.items()}

    return avg_location_ratings
