# exporter.py
import csv
import json

class DataExporter:
    def __init__(self, data):
        self.data = data

    def export(self, file_path):
        raise NotImplementedError("Subclasses should implement this!")

class TXTExporter(DataExporter):
    def export(self, file_path):
        with open(file_path, 'w') as file:
            for park, info in self.data.items():
                file.write(f"Park: {park}\n")
                for key, value in info.items():
                    file.write(f"{key.replace('_', ' ').capitalize()}: {value}\n")
                file.write("\n")

class CSVExporter(DataExporter):
    def export(self, file_path):
        with open(file_path, 'w', newline='') as file:
            writer = csv.writer(file)
            header = ['Park'] + list(next(iter(self.data.values())).keys())
            writer.writerow(header)
            for park, info in self.data.items():
                row = [park] + list(info.values())
                writer.writerow(row)

class JSONExporter(DataExporter):
    def export(self, file_path):
        with open(file_path, 'w') as file:
            json.dump(self.data, file, indent=4)